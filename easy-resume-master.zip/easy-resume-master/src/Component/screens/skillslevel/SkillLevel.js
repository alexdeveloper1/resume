import React, { Component } from 'react'
import './skilllevel.css'
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Button from '@mui/material/Button';
// import { Button } from 'bootstrap';
// import Checkbox from './Checkbox';

export default class SkillLevel extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentData: 0,
            limit: 2
        };
        this.selectData = this.selectData.bind(this);
    }

    selectData(event) {
        let isSelected = event.currentTarget.checked;
        if (isSelected) {
            if (this.state.currentData < this.state.limit) {
                this.setState({ currentData: this.state.currentData + 1 });
            } else {
                event.preventDefault()
                event.currentTarget.checked = false;
            }
        } else {
            this.setState({ currentData: this.state.currentData - 1 });
        }

        console.log(event);
    }

    render() {
        return (
            <Container className='body skilllivel'>
                <Row className='section-1'>
                    <Col className='main-headings'>
                        <h1 className='heading'>Which Industry is this resume for?</h1>
                        <h2 className='sub-heading'>You can select up to three industries.</h2>
                    </Col>
                </Row>
                <Row className='checkbox-group'>
                    <div className='col-checkbox'>
                        <div className='box-1'>
                            <input id="Addministrative" type="checkbox" onChange={(event) => this.selectData(event)}  />
                            <label htmlFor='Addministrative'>Administration</label>
                        </div>
                        <div className='box-1'>
                            <input id="Construction" type="checkbox" onChange={(id, event) => this.selectData(event)}  />
                            <label htmlFor='Construction'>Construction</label>
                        </div>
                        <div className='box-1'>
                            <input id="Food and Hotel" type="checkbox" onChange={(id, event) => this.selectData(event)}  />
                            <label htmlFor='Food and Hotel'>Food and Hotel</label>
                        </div>
                        <div className='box-1'>
                            <input id="Retail" type="checkbox" onChange={(id, event) => this.selectData(event)}  />
                            <label htmlFor='Retail'>Retail</label>
                        </div>
                        <div className='box-1'>
                            <input id="technology" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='technology'>technology</label>
                        </div>
                        <div className='box-1'>
                            <input id="Manufacturing" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Manufacturing'>Manufacturing</label>
                        </div>
                        <div className='box-1'>
                            <input id="Professional" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Professional'>Professional and Technical Services</label>
                        </div>
                        <div className='box-1'>
                            <input id="Transportation" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Transportation'>Transportation and Warehousing</label>
                        </div>
                        <div className='box-1'>
                            <input id="Information Technology" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Information Technology'>Information Technology</label>
                        </div>
                        <div className='box-1'>
                            <input id="Pharmaceutical" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Pharmaceutical'>Pharmaceutical</label>
                        </div>
                        <div className='box-1'>
                            <input id="Banking and Finance" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Banking and Finance'>Banking and Finance</label>
                        </div>
                        <div className='box-1'>
                            <input id="Hospitality" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Hospitality'>Hospitality</label>
                        </div>
                        <div className='box-1'>
                            <input id="Healthcare" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Healthcare'>Healthcare</label>
                        </div>
                        <div className='box-1'>
                            <input id="Sales" type="checkbox" onChange={(id, event) => this.selectData(event)} />
                            <label htmlFor='Sales'>Sales</label>
                        </div>
                    </div>
                </Row>
                <div className='btn-section'>
                    <button className='btn-col'>CONTINUE</button>
                </div>
                <div className='btn-2'>
                    <button className='btn-col-2'>Skip</button>
                </div>
                <footer className='section-3'>
                    <Container>
                        <Row className='footer'>
                            <Col className='menu-1' lg={6}>
                                <ul>
                                    <li>
                                        <a className='menu-linq' href='#'>Terms & Conditions</a>
                                    </li>
                                    <li>
                                        <a className='menu-linq' href='#'>Privacy Policy</a>
                                    </li>
                                    <li>
                                        <a className='menu-linq' href='#'>Contact Us</a>
                                    </li>
                                    <li>
                                        <a className='menu-linq' href='#'>Accessibility</a>
                                    </li>
                                </ul>
                            </Col>
                            <Col className='copy-right' lg={6}>
                                <a className='text-1'> 2021, NOW Limited. All rights reserved.</a>
                            </Col>
                        </Row>
                    </Container>
                </footer>
            </Container >
        )
    }
}