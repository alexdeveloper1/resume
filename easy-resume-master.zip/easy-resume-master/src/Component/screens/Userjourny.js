import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import logo from '../../assets/logo.png'
import './Userjourney.css'
import stepone from '../../assets/screenone/stepone.png'
import steptwo from '../../assets/screenone/steptwo.png'
import stepthree from '../../assets/screenone/stepthree.png';
import { Container, Row, Col } from 'react-bootstrap';

export default class Userjourny extends Component {
  render() {
    return (
      <>
        <Container className='body'>
          <Row className='logo'>
            <Col >
              <img src={logo} alt='' width={200} />
            </Col>
          </Row>
          <Row className='heading-1'>
            <p> How to Create a Job-Winning Resume </p>
          </Row>
          <Row className='section-1'>
            <Col className='col-1' lg={4} sm={1}>
              <div className='image-1'>
                <span class="count-hiw count-hiw-2">1</span>
                <img src={stepone} alt='' width={70} />
              </div>
              <p className='step-1'>Select from our professionally<br></br> designed, Recruiter approved<br></br> templates</p>
            </Col>
            <Col className='col-1' lg={4} sm={1}>
              <span className='thick-border-left clearfix'><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span>
              <div className='image-1'>
                <span class="count-hiw count-hiw-2">2</span>
                <img src={steptwo} alt='' width={70} />
              </div>
              <p className='step-1'>Complete each section using our<br></br> expert pre-written tips</p>
            </Col>
            <Col className='col-1' lg={4} sm={1}>
              <span className='thick-border-left clearfix'><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span>
              <div className='image-1'>
                <span class="count-hiw count-hiw-2">3</span>
                <img src={stepthree} alt='' width={80} />
              </div>
              <p className='step-1'>Easily customize your<br></br> resume for any job</p>
            </Col>
          </Row>
          <div className='section-2'>
            <button className='btn-1'><Link to={"/onboarding/career"}>CONTINUE</Link></button>
          </div>
        </Container>
        <footer className='section-3'>
          <Container>
            <Row className='footer'>
              <Col className='menu-1' lg={6}>
                <ul>
                  <li>
                    <a className='menu-linq' href='#'>Terms & Conditions</a>
                  </li>
                  <li>
                    <a className='menu-linq' href='#'>Privacy Policy</a>
                  </li>
                  <li>
                    <a className='menu-linq' href='#'>Contact Us</a>
                  </li>
                  <li>
                    <a className='menu-linq' href='#'>Accessibility</a>
                  </li>
                </ul>
              </Col>
              <Col className='copy-right' lg={6}>
                <a className='text-1'> 2021, NOW Limited. All rights reserved.</a>
              </Col>
            </Row>
          </Container>
        </footer>
      </>
    )
  }
}
