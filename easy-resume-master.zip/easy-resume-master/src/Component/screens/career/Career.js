import React, { Component, useEffect } from 'react'
import './career.css';
import logo from '../../../assets/logo.png';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';

export default class Career extends Component {
  constructor(props){
    super(props);
    this.state = {
      expLevel: "",
      checked: false
    };
    this.onchAnge = this.onchAnge.bind(this)
  }

onchAnge = (e) => {
  this.setState({
    expLevel: e.target.value,
    checked: true
  });

  console.log(this.state.expLevel);
}


  render() {
    return (
      <>
        <Container className='body career'>
          <Row className='main-row'>
            <Row className='logo'>
              <Col>
                <img src={logo} alt='' width={200} />
              </Col>
            </Row>
            <Row className='section-1'>
              <h1 className='heading'>How much work experience do you have?</h1>
              <h2 className='sub-heading'>We’ll point you in the right direction with the best templates for your experience level</h2>
            </Row>
            <Row className='level'>
              <Col>
                <input id="entry" type="checkbox" name="entry" 
                value="Entry"
                onChange={this.onchAnge}/>
                <label htmlFor='entry'>Entry Level</label>
              </Col>
              <Col>
                <input id="mid" type="checkbox" name="mid" 
                value="mid level"
                onChange={this.onchAnge} />
                <label htmlFor='mid' >Mid Level</label>
              </Col>
              <Col>
                <input id="sinior" type="checkbox" name="sinior" value="Senior"
                  onChange={this.onchAnge} />
                <label htmlFor='sinior'>Sinior Level</label>
              </Col>
            </Row>
            <Row className="exp-text-career">
              {this.state.expLevel === "Entry" ? <Col sm={4}>
                <p>
                  Great! Let’s get started!
                </p>
              </Col> : ""}
              {this.state.expLevel === "mid level" ?
              <Col sm={4}>
                <p>
                We’ll help you showcase your skills!
                </p>
              </Col> : ""}
              {this.state.expLevel === "Senior" ?
              <Col sm={4}>
                <p>
                We’ll show you how to present your expertise and skills!
                </p>
              </Col>
              : ""}
            </Row>
            <div className='btn-section'>
              <button className='btn-col'><Link to="/onboarding/skill_level">CONTINUE</Link></button>
            </div>
          </Row>
        </Container>
        <footer className='section-3'>
          <Container>
            <Row className='footer'>
              <Col className='menu-1' lg={6}>
                <ul>
                  <li>
                    <a className='menu-linq' href='#'>Terms & Conditions</a>
                  </li>
                  <li>
                    <a className='menu-linq' href='#'>Privacy Policy</a>
                  </li>
                  <li>
                    <a className='menu-linq' href='#'>Contact Us</a>
                  </li>
                  <li>
                    <a className='menu-linq' href='#'>Accessibility</a>
                  </li>
                </ul>
              </Col>
              <Col className='copy-right' lg={6}>
                <a className='text-1'> 2021, NOW Limited. All rights reserved.</a>
              </Col>
            </Row>
          </Container>
        </footer>
      </>
    )
  }
}
