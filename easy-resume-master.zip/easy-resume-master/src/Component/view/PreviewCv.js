import React from 'react'

export default function PreviewCv() {
  return (
    <div>PreviewCv</div>
  )
}
