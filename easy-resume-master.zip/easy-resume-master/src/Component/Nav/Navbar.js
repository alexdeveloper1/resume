import React from 'react'
// import { Link } from 'react-router-dom';
import { Container, Row, Col, Nav, Link } from 'react-bootstrap';
import logo from '../../assets/logo.png'

export default function Navbar() {
    return (
        <Container>
            <Row>
                <Col>
                <img src={logo} alt="logo" width={300}/>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Nav defaultActiveKey="/home" className="flex-column">
                        <Nav.Link href="/home">Active</Nav.Link>
                        <Nav.Link eventKey="link-1">Link</Nav.Link>
                        <Nav.Link eventKey="link-2">Link</Nav.Link>
                        <Nav.Link eventKey="disabled" disabled>
                            Disabled
                        </Nav.Link>
                    </Nav>
                </Col>
            </Row>
        </Container>
    )
}
