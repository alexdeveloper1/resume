import React from 'react';
import { Container, Row, Col, Nav } from 'react-bootstrap';
import Navbar from '../Nav/Navbar';
import { useParams } from 'react-router-dom';
import PersonalDetails from '../Form/PersonalDetails';
import PreviewCv from '../view/PreviewCv';
import './mainscreen.css'
import { Link } from 'react-router-dom';

export default function MainScreen() {
  let { currentParams } = useParams();
  return (
    <Container fluid className='Main-steps-screen'>
      <Row>
        <Col sm={3} className='asidee'>
          <Navbar />
        </Col>
        <Col className="main-steps">
          <Row>
            <Col className=''>
              <PersonalDetails />
            </Col>
            <Col className='PrevireCv'>
              <PreviewCv />
            </Col>
          </Row>
          <Row className='step-proceed-section'>
            <Col>
            <button className='btn-back-1'><Link to={"/onboarding/career"}>Back</Link></button>
            </Col>
            <Col>
              <button className='btn-1'><Link to={"/onboarding/career"}>CONTINUE</Link></button>
            </Col>
          </Row>
        </Col>
      </Row>
    </Container>
  )
}
