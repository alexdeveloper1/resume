import React, { useEffect, useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import { TextField } from '@mui/material';
import '../common.css';
import './employment.css'
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import styled from "styled-components";
import moment from "moment";
import { DatePicker, Space } from "antd";
import "antd/dist/antd.css";
export default function EmploymentFields() {
    const { params } = useParams();
    const [openDateRange, setOpenDateRange] = useState(true);
    const [sdate, setSdate] = useState(null)
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [hide, setHide] = useState(true)
    const [ehide, setEhide] = useState(true)
    function disabledDate(current) {
        return current > moment().endOf("day");
    }
    function onStartDateChange(dateString) {
        setStartDate(moment(dateString).format("MMM YYYY"));
        //   setHide(true)
        console.log(startDate);
    }
    function onEndDateChange(dateString) {
        setEndDate(moment(dateString).format("MMM YYYY"));
    }

    const onFocus = () => {
        setHide(false)
        console.log(hide);
    }

    const onBlur = () => {
        setHide(true)
        console.log(hide);
    }

    const handleChange = (e) => {
        setSdate(e.target.value)

        // console.log(value);
    }

    const eonFocus = () => {
        setEhide(false)
        console.log(hide);
    }

    const eonBlur = () => {
        setEhide(true)
        console.log(hide);
    }

    const handleFormChange = (index, event) => {
        event.preventDefault()
        let data = [...inputFields];
        data[index][event.target.name] = event.target.value;
        setInputFields(data);
        console.log(data);
    }
    const addFields = () => {
        let newfield = { jobTitle: '', employer: '', cityState: '', empcountry: '', startD: '', endD: '' }
        setInputFields([...inputFields, newfield])
    }

    const [inputFields, setInputFields] = useState([
        { jobTitle: '', employer: '', cityState: '', empcountry: '', startD: '', endD: '' }
      ])


    return (
        <div className='employment_fields'>
            <Container>
                {inputFields.map((input, index) => {
                    return (
                        <div key={index}>
                            <Row>
                                <Col className='aside'>
                                    <h1>
                                        Let's add your Experience
                                    </h1>
                                    <p>
                                        Start with your most recent job and work backwards
                                    </p>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        name='jobTitle'
                                        label="Job Title"
                                        fullWidth={true}
                                        onChange={event => handleFormChange(index, event)}
                                    // value={name}
                                    // onChange={handleChange}
                                    />
                                </Col>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        label="Employer"
                                        name="employer"
                                        fullWidth={true}
                                        onChange={event => handleFormChange(index, event)}
                                    // value={name}
                                    // onChange={handleChange}
                                    />
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        label="City - State"
                                        name="cityState"
                                        fullWidth={true}
                                        onChange={event => handleFormChange(index, event)}
                                    // value={name}
                                    // onChange={handleChange}
                                    />
                                </Col>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        label="Country"
                                        name="empcountry"
                                        fullWidth={true}
                                        onChange={event => handleFormChange(index, event)}
                                    // value={name}
                                    // onChange={handleChange}
                                    />
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        label="Start Date"
                                        name="startD"
                                        fullWidth={true}
                                        value={startDate}
                                        onChange={event => handleFormChange(index, event)}
                                        onFocus={onFocus}
                                        onBlur={onBlur}
                                        
                                    />
                                    {!hide ? <StyledSpace direction="horizontal" size={12}>

                                        <DatePicker
                                            dropdownClassName="styled__ant-picker-panel-container"
                                            picker="month"
                                            disabledDate={disabledDate}
                                            onChange={onStartDateChange}
                                            open={openDateRange}

                                        />
                                    </StyledSpace> : ""}
                                </Col>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        label="End Date"
                                        name="endD"
                                        fullWidth={true}
                                        value={endDate}
                                        onChange={event => handleFormChange(index, event)}
                                        onFocus={eonFocus}
                                        onBlur={eonBlur}
                                    />
                                    {!ehide ? <StyledSpace direction="horizontal" size={12}>

                                        <DatePicker
                                            dropdownClassName="styled__ant-picker-panel-container"
                                            picker="month"
                                            disabledDate={disabledDate}
                                            onChange={onEndDateChange}
                                            open={openDateRange}

                                        />
                                    </StyledSpace> : ""}

                                </Col>
                            </Row>

                        </div>

                    )
                })}
            </Container>
            <button onClick={addFields}>Add More..</button>sss
        </div>
    )
}
const StyledSpace = styled(Space)`
  .ant-space-item {
    visibility: hidden;
    min-width: 50%;
  }
`;
