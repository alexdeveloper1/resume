import React, { Component } from 'react';
import TextField from '@mui/material/TextField';
import { Container, Row, Col } from 'react-bootstrap';
import './personaldetails.css';

export default class PersonalDetails extends Component {
    render() {
        return (
            <div className='personal_details'>
                <Container>
                    <Row>
                        <Col className='aside'>
                            <h1>
                                Let’s start with your header
                            </h1>
                            <p>
                                Include your full name and at least one way for employers to reach you.
                            </p>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                        
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <TextField
                                id="outlined-name"
                                label="First Name"
                                fullWidth={true}
                            // value={name}
                            // onChange={handleChange}
                            />
                        </Col>
                        <Col>
                            <TextField
                                id="outlined-name"
                                label="Last Name"
                                fullWidth={true}
                            // value={name}
                            // onChange={handleChange}
                            />
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <TextField
                                id="outlined-name"
                                label="City-State"
                                fullWidth={true}
                            // value={name}
                            // onChange={handleChange}
                            />
                        </Col>
                        <Col>
                            <Row>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        label="Postal Code"
                                        fullWidth={true}
                                    // value={name}
                                    // onChange={handleChange}
                                    />
                                </Col>
                                <Col>
                                    <TextField
                                        id="outlined-name"
                                        label="Country"
                                        fullWidth={true}
                                    // value={name}
                                    // onChange={handleChange}
                                    />
                                </Col>
                            </Row>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <TextField
                                id="outlined-name"
                                label="Phone"
                                fullWidth={true}
                                // value={name}
                                // onChange={handleChange}
                            />
                        </Col>
                        <Col>
                        <TextField
                                id="outlined-name"
                                label="Email"
                                fullWidth={true}
                                // value={name}
                                // onChange={handleChange}
                            />
                        </Col>
                    </Row>
                </Container>
            </div>
        )
    }
}
