import React from 'react';
import Userjourny from './Component/screens/Userjourny';
import Career from './Component/screens/career/Career';
import PersonalDetails from './Component/Form/PersonalDetails';
import EmploymentFields from './Component/Form/Employment/EmploymentFields';
import SkillLevel from './Component/screens/skillslevel/SkillLevel';
import MainScreen from './Component/steps/MainScreen';
import {
  BrowserRouter as Router,
  Redirect,
  Routes,
  Route,
  Switch
} from "react-router-dom";
function App() {
  return(
    <Router>
    <Routes>
      <Route path="/" element={<Userjourny />} />
      <Route path="/onboarding/career" element={<Career />} />
      <Route path="/onboarding/personal_details" element={<PersonalDetails />} />
      <Route path="/onboarding/emp-fields/:params" element={<EmploymentFields />}/> 
      <Route path="/onboarding/steps/:id" element={<MainScreen />}/>
      <Route path="/onboarding/skill_level" element={<SkillLevel />} />
      {/* <Route Component={Error} /> */}
    </Routes>
  </Router>
  );
}

export default App;