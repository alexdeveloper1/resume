import React, { Component } from 'react'
import Userjourny from './src/Component/screens/Userjourny';
import Career from './src/Component/screens/career/Career';
import main from './src/Component/steps/MainScreen';

export default class welcom extends Component {
  render() {
    return (
      <div>
          <Userjourny />
          <Career />

      </div>
    )
  }
}
